* 565ddbe - (31 seconds ago) echo 'd' > 3 - Shijing Lu (HEAD -> master)
*   7dcb276 - (3 minutes ago) Merge branch 'feature/dev' - Shijing Lu
|\  
| * e5b2842 - (16 minutes ago) echo "commit 3: echo 'b' > b" >> README.md - Shijing Lu (feature/dev)
| * c15d456 - (19 minutes ago) echo 'b' > b - Shijing Lu
* | f80e0b1 - (6 minutes ago) echo "commit 4: echo 'c' > c" >> README.md - Shijing Lu
* | 0f31627 - (7 minutes ago) echo 'c' > c - Shijing Lu
* | 8ac4091 - (7 minutes ago) echo "commit 3: echo 'b' > b" >> README.md - Shijing Lu
* | 003e1a7 - (16 minutes ago) echo 'b 2' > b - Shijing Lu
|/  
* 67a3675 - (21 minutes ago) add README.md - Shijing Lu (tag: v0.1)
* f7b4593 - (23 minutes ago) commit 1 - Shijing Lu
* 42bab7a - (23 minutes ago) commit 0 - Shijing Lu